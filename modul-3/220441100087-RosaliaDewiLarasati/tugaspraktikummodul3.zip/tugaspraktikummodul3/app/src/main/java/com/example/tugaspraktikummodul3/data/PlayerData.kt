package com.example.tugaspraktikummodul3.data

data class PlayerData(
    val name: String,
    val tempat:String,
    val description: String,
    val image: Int
)
