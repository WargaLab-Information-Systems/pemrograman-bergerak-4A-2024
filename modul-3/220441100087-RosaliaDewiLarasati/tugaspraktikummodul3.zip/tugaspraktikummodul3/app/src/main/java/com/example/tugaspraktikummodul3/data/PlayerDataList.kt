package com.example.tugaspraktikummodul3.data

import com.example.tugaspraktikummodul3.R
object PlayerDataList {
    // Dummy data yang nantinya akan kita tampilkan di dalam Aplikasi
    object PlayerDataList {
        val DataDummy = arrayListOf(
            PlayerData(
                "Amaris Hotel Simpang Lima",
                "\uD83D\uDC65 2.394 ★4,3",
                "Bagi Anda yang menginginkan kualitas pelayanan oke dengan harga yang ramah di kantong, Amaris Hotel Simpang Lima Semarang adalah pilihan yang tepat. Karena meski murah, akomodasi ini menyediakan fasilitas memadai dan pelayanan yang tetap terjaga mutunya. Amaris Hotel Simpang Lima Semarang adalah pilihan cerdas bagi Anda yang ingin menginap di hotel dengan harga terjangkau, namun tetap memberikan pelayanan yang baik.Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda. Terdapat restoran yang menyajikan menu lezat ala Amaris Hotel Simpang Lima Semarang khusus untuk Anda",
                R.drawable.amarishotel
            ),
            PlayerData(
                "ASTON Mojokerto Hotel & Conference Center",
                "\uD83D\uDC65 850 ★4,7",
                "ASTON Mojokerto Hotel & Conference Center memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Jika Anda memiliki agenda kegiatan yang membutuhkan ruangan besar, maka ASTON Mojokerto Hotel & Conference Center adalah pilihan yang tepat. Hotel ini memiliki ruang pertemuan yang luas dan dilengkapi dengan berbagai fasilitas penunjang. ASTON Mojokerto Hotel & Conference Center adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda.",
                R.drawable.astonmojokerto
            ),
            PlayerData(
                "Atria Hotel Magelang",
                "\uD83D\uDC65 7.791 ★4,4",
                "Jika anda mencari suasana hotel sesuai untuk keluarga di Magelang, coba lihat Atria Hotel Magelang. Karena berdekatan dengan Alun-Alun Kota Magelang (2,5 km), para tamu Atria Hotel Magelang dapat mengunjungi salah satu lokasi populer di Magelang. Kamar tamu memiliki tv layar datar, penyejuk udara, dan minibar, dan Atria Hotel Magelang membuat terhubung dengan internet semakin mudah karena menawarkan wi-fi gratis. Anda juga dapat menggunakan fasilitas yang disediakan oleh hotel, seperti resepsionis 24 jam, layanan concierge, dan layanan kamar. Para tamu juga dapat menikmati kolam renang dan sarapan saat mereka menginap. Untuk menambah kenyamanan, parkir gratis tersedia untuk para tamu.",
                R.drawable.atriahotelmagelang
            ),
            PlayerData(
                "Ayola Sunrise",
                "\uD83D\uDC65 3.597 ★4,5",
                "Ayola Sunrise Hotel Mojokerto memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pelayanan memuaskan serta fasilitas hotel yang memadai akan membuat Anda nyaman berada di Ayola Sunrise Hotel Mojokerto. Pusat kebugaran menjadi salah satu fasilitas yang wajib Anda coba saat menginap di tempat ini. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda. Terdapat restoran yang menyajikan menu lezat ala Ayola Sunrise Hotel Mojokerto khusus untuk Anda. WiFi tersedia di seluruh area publik properti untuk membantu Anda tetap terhubung dengan keluarga dan teman.",
                R.drawable.ayolasunrise
            ),
            PlayerData(
                "Bumi Surabaya City Resort",
                "\uD83D\uDC65 12.907 ★4,7",
                "Bumi Surabaya City Resort memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Kualitas pelayanan super, ditambah berbagai fasilitas unggulan akan membuat saat-saat menginap di sini menjadi sebuah pengalaman berkesan yang luar biasa. Tersedia kolam renang untuk Anda bersantai sendiri maupun bersama teman dan keluarga. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda",
                R.drawable.bumisurabaya
            ),
            PlayerData(
                "The 1O1 Malang OJ ",
                "\uD83D\uDC65 7.926 ★4,6",
                "THE 1O1 Malang OJ memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda. Pusat kebugaran menjadi salah satu fasilitas yang wajib Anda coba saat menginap di tempat ini. Tersedia kolam renang untuk Anda bersantai sendiri maupun bersama teman dan keluarga. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda.Terdapat restoran yang menyajikan menu lezat ala THE 1O1 Malang OJ khusus untuk Anda.",
                R.drawable.hotelmalang
            ),
            PlayerData(
                "Hotel Sriti",
                "\uD83D\uDC65 1.639 ★4,5",
                "Hotel Sriti Magelang menyediakan tempat menginap yang tak hanya nyaman untuk beristirahat, tapi juga desain cantik yang memanjakan mata Anda. Hotel Sriti Magelang memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Hotel Sriti Magelang adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. Jika Anda berniat menginap dalam jangka waktu yang lama, Hotel Sriti Magelang adalah pilihan tepat. Berbagai fasilitas yang tersedia dan kualitas pelayanan yang baik akan membuat Anda merasa sedang berada di rumah sendiri.",
                R.drawable.hotelsriti
            ),
            PlayerData(
                "Hotel Tugu Malang",
                "\uD83D\uDC65 3.664 ★4,7",
                "Hotel Tugu Malang, bagian dari Tugu Hotels, Resorts & Restaurants Indonesia, terletak tepat di jantung pusat kota tua, menghadap “Jan Pieterszoon Coen Plein” alun-alun kota tua utama yang setelah era kemerdekaan Indonesia, sekitar tahun 1946, menjadi salah satu monumen peringatan kemerdekaan pertama yang dibangun di Indonesia, yang saat ini dilengkapi dengan kolam teratai yang sangat megah. Hotel Tugu Malang adalah cara yang paling utama dalam menikmati kekayaan sejarah Jawa yang indah, dengan banyak ruang terbuka, menawarkan 49 kamar tamu yang indah dilengkapi dengan fasilitas modern. Semua kamar memiliki akses sirkulasi udara segar yang diberikan oleh jendela lebar di pada setiap kamar, para tamu dapat menikmati angin sejuk Kota Malang.",
                R.drawable.hoteltugumalang
            ),
            PlayerData(
                "Pandanaran Hotel Semarang",
                "\uD83D\uDC65 7.175 ★4,4",
                "Jika Anda memiliki agenda kegiatan yang membutuhkan ruangan besar, maka Pandanaran Simpang Lima adalah pilihan yang tepat. Hotel ini memiliki ruang pertemuan yang luas dan dilengkapi dengan berbagai fasilitas penunjang. Pandanaran Simpang Lima memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda.",
                R.drawable.pandanaranhotel
            ),
            PlayerData(
                "Surabaya River View Hotel",
                "\uD83D\uDC65 2469 ★4,6",
                "Bagi Anda yang menginginkan kualitas pelayanan oke dengan harga yang ramah di kantong, Surabaya River View Hotel adalah pilihan yang tepat. Karena meski murah, akomodasi ini menyediakan fasilitas memadai dan pelayanan yang tetap terjaga mutunya. Surabaya River View Hotel memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Surabaya River View Hotel adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. hotel ini adalah pilihan tepat bagi Anda dan pasangan yang ingin menikmati liburan romantis. Dapatkan pengalaman yang penuh kesan bersama pasangan dengan menginap di Surabaya River View Hotel.",
                R.drawable.surabayariverviewhotel
            ),
        )

        val DataAdapter= arrayListOf(
            PlayerData(
                "Amaris Hotel Simpang Lima",
                "⟟ Semarang",
                "Bagi Anda yang menginginkan kualitas pelayanan oke dengan harga yang ramah di kantong, Amaris Hotel Simpang Lima Semarang adalah pilihan yang tepat. Karena meski murah, akomodasi ini menyediakan fasilitas memadai dan pelayanan yang tetap terjaga mutunya. Amaris Hotel Simpang Lima Semarang adalah pilihan cerdas bagi Anda yang ingin menginap di hotel dengan harga terjangkau, namun tetap memberikan pelayanan yang baik.Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda. Terdapat restoran yang menyajikan menu lezat ala Amaris Hotel Simpang Lima Semarang khusus untuk Anda.",
                R.drawable.amarishotel
            ),
            PlayerData(
                "ASTON Mojokerto Hotel & Conference Center",
                "⟟ Mojokerto",
                "ASTON Mojokerto Hotel & Conference Center memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Jika Anda memiliki agenda kegiatan yang membutuhkan ruangan besar, maka ASTON Mojokerto Hotel & Conference Center adalah pilihan yang tepat. Hotel ini memiliki ruang pertemuan yang luas dan dilengkapi dengan berbagai fasilitas penunjang. ASTON Mojokerto Hotel & Conference Center adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda.",
                R.drawable.astonmojokerto
            ),
            PlayerData(
                "Atria Hotel Magelang",
                "⟟ Magelang",
                "Jika anda mencari suasana hotel sesuai untuk keluarga di Magelang, coba lihat Atria Hotel Magelang. Karena berdekatan dengan Alun-Alun Kota Magelang (2,5 km), para tamu Atria Hotel Magelang dapat mengunjungi salah satu lokasi populer di Magelang. Kamar tamu memiliki tv layar datar, penyejuk udara, dan minibar, dan Atria Hotel Magelang membuat terhubung dengan internet semakin mudah karena menawarkan wi-fi gratis. Anda juga dapat menggunakan fasilitas yang disediakan oleh hotel, seperti resepsionis 24 jam, layanan concierge, dan layanan kamar. Para tamu juga dapat menikmati kolam renang dan sarapan saat mereka menginap. Untuk menambah kenyamanan, parkir gratis tersedia untuk para tamu.",
                R.drawable.atriahotelmagelang
            ),
            PlayerData(
                "Ayola Sunrise",
                "⟟ Mojokerto",
                "Ayola Sunrise Hotel Mojokerto memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pelayanan memuaskan serta fasilitas hotel yang memadai akan membuat Anda nyaman berada di Ayola Sunrise Hotel Mojokerto. Pusat kebugaran menjadi salah satu fasilitas yang wajib Anda coba saat menginap di tempat ini. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda. Terdapat restoran yang menyajikan menu lezat ala Ayola Sunrise Hotel Mojokerto khusus untuk Anda. WiFi tersedia di seluruh area publik properti untuk membantu Anda tetap terhubung dengan keluarga dan teman. ",
                R.drawable.ayolasunrise
            ),
            PlayerData(
                "Bumi Surabaya City Resort",
                "⟟ Surabaya",
                "Bumi Surabaya City Resort memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Kualitas pelayanan super, ditambah berbagai fasilitas unggulan akan membuat saat-saat menginap di sini menjadi sebuah pengalaman berkesan yang luar biasa. Tersedia kolam renang untuk Anda bersantai sendiri maupun bersama teman dan keluarga. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda",
                R.drawable.bumisurabaya
            ),
            PlayerData(
                "The 1O1 Malang OJ",
                "⟟ Malang",
                "THE 1O1 Malang OJ memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda. Pusat kebugaran menjadi salah satu fasilitas yang wajib Anda coba saat menginap di tempat ini. Tersedia kolam renang untuk Anda bersantai sendiri maupun bersama teman dan keluarga. Resepsionis siap 24 jam untuk melayani proses check-in, check-out dan kebutuhan Anda yang lain. Jangan ragu untuk menghubungi resepsionis, kami siap melayani Anda.Terdapat restoran yang menyajikan menu lezat ala THE 1O1 Malang OJ khusus untuk Anda.",
                R.drawable.hotelmalang
            ),
            PlayerData(
                "Hotel Sriti",
                "⟟ Magelang",
                "Hotel Sriti Magelang menyediakan tempat menginap yang tak hanya nyaman untuk beristirahat, tapi juga desain cantik yang memanjakan mata Anda. Hotel Sriti Magelang memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Hotel Sriti Magelang adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. Jika Anda berniat menginap dalam jangka waktu yang lama, Hotel Sriti Magelang adalah pilihan tepat. Berbagai fasilitas yang tersedia dan kualitas pelayanan yang baik akan membuat Anda merasa sedang berada di rumah sendiri.",
                R.drawable.hotelsriti
            ),
            PlayerData(
                "Hotel Tugu Malang",
                "⟟ Malang",
                "Hotel Tugu Malang, bagian dari Tugu Hotels, Resorts & Restaurants Indonesia, terletak tepat di jantung pusat kota tua, menghadap “Jan Pieterszoon Coen Plein” alun-alun kota tua utama yang setelah era kemerdekaan Indonesia, sekitar tahun 1946, menjadi salah satu monumen peringatan kemerdekaan pertama yang dibangun di Indonesia, yang saat ini dilengkapi dengan kolam teratai yang sangat megah. Hotel Tugu Malang adalah cara yang paling utama dalam menikmati kekayaan sejarah Jawa yang indah, dengan banyak ruang terbuka, menawarkan 49 kamar tamu yang indah dilengkapi dengan fasilitas modern. Semua kamar memiliki akses sirkulasi udara segar yang diberikan oleh jendela lebar di pada setiap kamar, para tamu dapat menikmati angin sejuk Kota Malang.",
                R.drawable.hoteltugumalang
            ),
            PlayerData(
                "Pandanaran Hotel Semarang",
                "⟟ Semarang",
                "Jika Anda memiliki agenda kegiatan yang membutuhkan ruangan besar, maka Pandanaran Simpang Lima adalah pilihan yang tepat. Hotel ini memiliki ruang pertemuan yang luas dan dilengkapi dengan berbagai fasilitas penunjang. Pandanaran Simpang Lima memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Pengalaman menginap Anda tak akan terlupakan berkat pelayanan istimewa yang disertai oleh berbagai fasilitas pendukung untuk kenyamanan Anda.",
                R.drawable.pandanaranhotel
            ),
            PlayerData(
                "Surabaya River View Hotel",
                "⟟ Surabaya",
                "Bagi Anda yang menginginkan kualitas pelayanan oke dengan harga yang ramah di kantong, Surabaya River View Hotel adalah pilihan yang tepat. Karena meski murah, akomodasi ini menyediakan fasilitas memadai dan pelayanan yang tetap terjaga mutunya. Surabaya River View Hotel memiliki segala fasilitas penunjang bisnis untuk Anda dan kolega. Surabaya River View Hotel adalah tempat bermalam yang tepat bagi Anda yang berlibur bersama keluarga. Nikmati segala fasilitas hiburan untuk Anda dan keluarga. hotel ini adalah pilihan tepat bagi Anda dan pasangan yang ingin menikmati liburan romantis. Dapatkan pengalaman yang penuh kesan bersama pasangan dengan menginap di Surabaya River View Hotel.",
                R.drawable.surabayariverviewhotel
            ),
        )
    }
}