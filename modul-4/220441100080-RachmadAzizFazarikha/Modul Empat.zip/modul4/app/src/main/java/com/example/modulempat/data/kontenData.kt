package com.example.modulempat.data

data class kontenData(
    val id: Int,
    val deskripsi: String,
    val image: Int,
    val like: Int
)
