package com.vinz.latihanrecyclerviewpraktikum.activity.practice

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.vinz.latihanrecyclerviewpraktikum.R

class UpdatePeopleRoomActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_people_room)
    }
}