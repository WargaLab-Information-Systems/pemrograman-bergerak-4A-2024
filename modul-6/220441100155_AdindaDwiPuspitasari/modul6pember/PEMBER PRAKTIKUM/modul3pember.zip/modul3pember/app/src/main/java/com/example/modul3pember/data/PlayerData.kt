package com.example.modul3pember.data

data class PlayerData(
    val name: String,
    val tempat:String,
    val description: String,
    val image: Int
)