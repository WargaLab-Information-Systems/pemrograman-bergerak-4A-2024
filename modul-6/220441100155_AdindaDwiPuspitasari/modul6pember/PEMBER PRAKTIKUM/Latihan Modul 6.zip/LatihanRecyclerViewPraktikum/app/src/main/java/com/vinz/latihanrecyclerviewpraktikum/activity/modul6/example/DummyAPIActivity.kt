package com.vinz.latihanrecyclerviewpraktikum.activity.modul6.example

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.ProgressBar
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.vinz.latihanrecyclerviewpraktikum.DetailPlayerActivity
import com.vinz.latihanrecyclerviewpraktikum.R
import com.vinz.latihanrecyclerviewpraktikum.activity.modul6.practice.RetrofitActivity
import com.vinz.latihanrecyclerviewpraktikum.adapter.modul6.example.PlayerAdapterRetrofit
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleAPIResponse
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleViewModel
import com.vinz.latihanrecyclerviewpraktikum.data.remote.example.ExampleViewModelFactory

// Kelas ini digunakan untuk menampilkan daftar pemain dan interaksi lainnya
class DummyAPIActivity : AppCompatActivity() {
    // Mendeklarasikan variabel untuk ViewModel
    private lateinit var exampleViewModel: ExampleViewModel
    // Mendeklarasikan variabel untuk adapter RecyclerView
    private lateinit var adapter: PlayerAdapterRetrofit
    // Mendeklarasikan variabel untuk RecyclerView
    private lateinit var recyclerView: RecyclerView

    // Fungsi ini dipanggil saat activity dibuat
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dummy_apiactivity)

        // Membuat instance dari ViewModel
        val factory = ExampleViewModelFactory.getInstance()
        exampleViewModel = ViewModelProvider(this, factory)[ExampleViewModel::class.java]

        // Menghubungkan variabel recyclerView dengan komponen di layout
        recyclerView = findViewById(R.id.rv_player_retrofit)
        // Mengatur layoutManager untuk recyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Memanggil fungsi untuk mendapatkan semua pemain
        exampleViewModel.getAllPlayer()
        // Mengamati data pemain dari ViewModel
        exampleViewModel.listPlayer.observe(this) { listPlayer ->
            // Jika listPlayer tidak kosong
            if (listPlayer.isNotEmpty()) {

                // Membuat instance dari adapter dan mengatur adapter untuk recyclerView
                adapter = PlayerAdapterRetrofit(listPlayer)
                recyclerView.adapter = adapter

                // Mengatur callback ketika item di klik, di edit, dan di hapus
                adapter.setOnItemClickCallback(object : PlayerAdapterRetrofit.OnItemClickCallback {
                    override fun onItemClicked(data: ExampleAPIResponse) {
                        // Menampilkan pemain yang dipilih
                        showSelectedPlayer(data)
                    }

                    override fun onEditClicked(data: ExampleAPIResponse) {
                        // Membuat intent untuk berpindah ke UpdateDummyAPIActivity
                        val intent =
                            Intent(
                                this@DummyAPIActivity,
                                UpdateDummyAPIActivity::class.java
                            )
                        // Menambahkan data pemain ke intent
                        intent.putExtra("player", data)
                        // Memulai activity baru
                        startActivity(intent)
                    }

                    override fun onDeleteClicked(data: ExampleAPIResponse, position: Int) {
                        // Menampilkan dialog konfirmasi penghapusan pemain
                        popUpDeletePlayer(data, position)
                    }

                })
            }
        }

        // Mengamati data pemain dari ViewModel
        exampleViewModel.player.observe(this) { player ->
            // Jika player tidak null, memanggil fungsi untuk mendapatkan semua pemain
            if (player != null) {
                exampleViewModel.getAllPlayer()
            }
        }

        // Mengamati status loading dari ViewModel
        exampleViewModel.isLoading.observe(this) {
            // Menampilkan atau menyembunyikan loading berdasarkan status loading
            showLoading(it)
        }

        // Mengatur aksi ketika tombol tambah pemain diklik
        val btnAdd = findViewById<FloatingActionButton>(R.id.btn_add_player)
        btnAdd.setOnClickListener {
            // Membuat intent untuk berpindah ke AddDummyAPIActivity
            val intent = Intent(this, AddDummyAPIActivity::class.java)
            // Memulai activity baru
            startActivity(intent)
        }

        // Mengatur aksi ketika tombol wifi diklik
        val btnWifi = findViewById<ImageView>(R.id.navigate_retrofit)
        btnWifi.setOnClickListener {
            // Membuat intent untuk berpindah ke RetrofitActivity
            val intent = Intent(this, RetrofitActivity::class.java)
            // Memulai activity baru
            startActivity(intent)
        }
    }

    // Fungsi untuk menampilkan atau menyembunyikan loading
    private fun showLoading(isLoading: Boolean) {
        val loading = findViewById<ProgressBar>(R.id.progressBar)
        // Jika isLoading true, tampilkan loading. Jika false, sembunyikan loading
        loading.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    // Fungsi untuk menampilkan pemain yang dipilih
    private fun showSelectedPlayer(data: ExampleAPIResponse) {
        // Membuat intent untuk berpindah ke DetailPlayerActivity
        val navigateToDetail = Intent(this, DetailPlayerActivity::class.java)

        // Menambahkan data pemain ke intent
        navigateToDetail.putExtra("playerAPI", data)

        // Memulai activity baru
        startActivity(navigateToDetail)
    }

    // Fungsi untuk menampilkan dialog konfirmasi penghapusan pemain
    private fun popUpDeletePlayer(data: ExampleAPIResponse, position: Int) {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Hapus Player")
        builder.setMessage("Apakah anda yakin ingin menghapus player ini?")
        builder.setPositiveButton("Ya") { _, _ ->
            // Jika "Ya" diklik, hapus pemain
            exampleViewModel.deletePlayer(data.id)
        }

        builder.setNegativeButton("Tidak") { dialog, _ ->
            // Jika "Tidak" diklik, batalkan dialog
            dialog.cancel()
        }
        builder.show()
    }

    // Fungsi ini dipanggil saat activity di restart
    override fun onRestart() {
        super.onRestart()
        // Memanggil fungsi untuk mendapatkan semua pemain
        exampleViewModel.getAllPlayer()
    }
}