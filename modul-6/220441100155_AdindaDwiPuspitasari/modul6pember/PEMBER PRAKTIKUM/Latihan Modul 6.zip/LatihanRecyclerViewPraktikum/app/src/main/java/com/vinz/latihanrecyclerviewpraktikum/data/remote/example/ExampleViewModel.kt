package com.vinz.latihanrecyclerviewpraktikum.data.remote.example

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel

// Kelas ini digunakan untuk mengelola data dan berinteraksi dengan repository
class ExampleViewModel(private val exampleRepository: ExampleRepository) : ViewModel() {

    // Mendeklarasikan variabel listPlayer yang berisi LiveData dari List ExampleAPIResponse dari repository
    val listPlayer: LiveData<List<ExampleAPIResponse>> = exampleRepository.listPlayer

    // Mendeklarasikan variabel isLoading yang berisi LiveData dari Boolean (status loading) dari repository
    val isLoading: LiveData<Boolean> = exampleRepository.isLoading

    // Mendeklarasikan variabel player yang berisi LiveData dari ExampleAPIResponse dari repository
    val player: LiveData<ExampleAPIResponse> = exampleRepository.player

    // Fungsi untuk mendapatkan semua pemain dari repository
    fun getAllPlayer() {
        exampleRepository.getAllPlayer()
    }

    // Fungsi untuk mendapatkan detail pemain berdasarkan id dari repository
    fun getDetailPlayer(id: String) {
        exampleRepository.getDetailPlayer(id)
    }

    // Fungsi untuk menambahkan pemain ke repository
    fun addPlayer(player: ExampleAPIRequest) {
        exampleRepository.addPlayer(player)
    }

    // Fungsi untuk memperbarui pemain berdasarkan id di repository
    fun updatePlayer(id: String, player: ExampleAPIRequest) {
        exampleRepository.updatePlayer(id, player)
    }

    // Fungsi untuk menghapus pemain berdasarkan id dari repository
    fun deletePlayer(id: String) {
        exampleRepository.deletePlayer(id)
    }
}