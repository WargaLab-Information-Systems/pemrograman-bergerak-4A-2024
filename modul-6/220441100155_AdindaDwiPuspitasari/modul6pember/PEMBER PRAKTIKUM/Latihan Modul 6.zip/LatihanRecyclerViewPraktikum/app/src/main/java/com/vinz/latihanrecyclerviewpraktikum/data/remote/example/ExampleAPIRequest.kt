package com.vinz.latihanrecyclerviewpraktikum.data.remote.example

import com.google.gson.annotations.SerializedName

// Kelas ini digunakan untuk merepresentasikan permintaan API
data class ExampleAPIRequest(

    // Anotasi SerializedName digunakan untuk mapping antara variabel dan field JSON saat proses serialisasi dan deserialisasi
    // Variabel "name" akan dipetakan ke field JSON "name"
    @field:SerializedName("name")
    val name: String,

    // Variabel "avatar" akan dipetakan ke field JSON "avatar"
    @field:SerializedName("avatar")
    val avatar: String,

    // Variabel "description" akan dipetakan ke field JSON "description"
    @field:SerializedName("description")
    val description: String
)