package com.vinz.latihanrecyclerviewpraktikum.data.remote.practice

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

// Kelas ini digunakan untuk menyimpan data makanan
data class Food(
    // Anotasi ini digunakan untuk menghubungkan variabel dengan field JSON
    @field:SerializedName("id")
    // Variabel ini digunakan untuk menyimpan id makanan
    val id: Int,

    @field:SerializedName("name")
    // Variabel ini digunakan untuk menyimpan nama makanan
    val name: String,

    @field:SerializedName("price")
    // Variabel ini digunakan untuk menyimpan harga makanan
    val price: Int,

    @field:SerializedName("description")
    // Variabel ini digunakan untuk menyimpan deskripsi makanan
    val description: String,

    @field:SerializedName("image")
    // Variabel ini digunakan untuk menyimpan URL gambar makanan
    val image: String
) : Parcelable {
    // Konstruktor ini digunakan untuk membuat objek Food dari Parcel
    constructor(parcel: Parcel) : this(
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readInt(),
        parcel.readString()!!,
        parcel.readString()!!
    )

    // Fungsi ini digunakan untuk menulis data Food ke Parcel
    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeInt(id)
        dest.writeString(name)
        dest.writeInt(price)
        dest.writeString(description)
        dest.writeString(image)
    }

    // Fungsi ini digunakan untuk mendeskripsikan jenis konten khusus yang ditangani oleh Parcelable
    override fun describeContents(): Int {
        return 0
    }

    // Objek companion yang digunakan untuk membuat objek Food dari Parcel dan array dari Food
    companion object CREATOR : Parcelable.Creator<Food> {
        // Fungsi ini digunakan untuk membuat objek Food dari Parcel
        override fun createFromParcel(source: Parcel): Food {
            return Food(source)
        }

        // Fungsi ini digunakan untuk membuat array dari Food
        override fun newArray(size: Int): Array<Food?> {
            return arrayOfNulls(size)
        }
    }
}