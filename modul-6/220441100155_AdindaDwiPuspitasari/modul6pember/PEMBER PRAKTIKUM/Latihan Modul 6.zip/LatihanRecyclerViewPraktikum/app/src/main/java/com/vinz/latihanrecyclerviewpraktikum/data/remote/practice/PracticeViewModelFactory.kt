package com.vinz.latihanrecyclerviewpraktikum.data.remote.practice

class PracticeViewModelFactory {
}