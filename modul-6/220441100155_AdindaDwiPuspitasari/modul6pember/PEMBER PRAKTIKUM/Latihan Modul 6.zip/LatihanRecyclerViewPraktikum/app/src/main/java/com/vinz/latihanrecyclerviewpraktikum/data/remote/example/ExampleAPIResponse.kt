package com.vinz.latihanrecyclerviewpraktikum.data.remote.example

import android.os.Parcel
import android.os.Parcelable
import com.google.gson.annotations.SerializedName

// Kelas ini digunakan untuk merepresentasikan respons API
data class ExampleAPIResponse(

    // Anotasi SerializedName digunakan untuk mapping antara variabel dan field JSON saat proses serialisasi dan deserialisasi
    // Variabel "name" akan dipetakan ke field JSON "name"
    @field:SerializedName("name")
    val name: String,

    // Variabel "avatar" akan dipetakan ke field JSON "avatar"
    @field:SerializedName("avatar")
    val avatar: String,

    // Variabel "description" akan dipetakan ke field JSON "description"
    @field:SerializedName("description")
    val description: String,

    // Variabel "id" akan dipetakan ke field JSON "id"
    @field:SerializedName("id")
    val id: String

) : Parcelable {
    // Konstruktor ini digunakan saat membaca data dari Parcel
    constructor(parcel: Parcel) : this(
        parcel.readString()!!, // Membaca string "name" dari Parcel
        parcel.readString()!!, // Membaca string "avatar" dari Parcel
        parcel.readString()!!, // Membaca string "description" dari Parcel
        parcel.readString()!!  // Membaca string "id" dari Parcel
    )

    // Fungsi ini digunakan untuk menulis data ke Parcel
    override fun writeToParcel(dest: Parcel, flags: Int) {
        dest.writeString(name) // Menulis string "name" ke Parcel
        dest.writeString(avatar) // Menulis string "avatar" ke Parcel
        dest.writeString(description) // Menulis string "description" ke Parcel
        dest.writeString(id) // Menulis string "id" ke Parcel
    }

    // Fungsi ini digunakan untuk mendeskripsikan jenis konten khusus yang ditangani oleh Parcelable instance
    override fun describeContents(): Int {
        return 0
    }

    // Objek CREATOR digunakan untuk membuat instance baru dari Parcelable class, baik dari Parcel yang telah ada atau array baru
    companion object CREATOR : Parcelable.Creator<ExampleAPIResponse> {
        // Membuat instance baru dari Parcelable class dari Parcel yang telah ada
        override fun createFromParcel(parcel: Parcel): ExampleAPIResponse {
            return ExampleAPIResponse(parcel)
        }

        // Membuat array baru dari Parcelable class
        override fun newArray(size: Int): Array<ExampleAPIResponse?> {
            return arrayOfNulls(size)
        }
    }
}